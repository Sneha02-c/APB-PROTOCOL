var g_data = {"2":["work.APB_TOP_sv_unit",100.00,1],"8":["work.apb_asser",100.00,1]};
processDuLinks(g_data);