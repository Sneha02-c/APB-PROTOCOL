var g_data = {"data":[{"n":"work.APB_TOP_sv_unit","id":2,"zf":1,"tc":100.00,"g":100.00},{"n":"work.apb_asser","id":8,"zf":1,"tc":100.00,"a":100.00}]};
processDuData(g_data);