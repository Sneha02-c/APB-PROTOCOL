var g_db_data = {"12":1,"11":1,"9":1,"2":1,"8":1};
processScopesDbFile(g_db_data);